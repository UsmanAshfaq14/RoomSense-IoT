// RoomSense server, v1: MQTT broker + MongoDB + REST API in ONE Node.js process.
// The broker lives inside this process, so it is the only component that talks to the database.
// The Raspberry Pi only ever talks MQTT to this broker.
//
// Start:   node server.js          (MongoDB must be running on this laptop)
// Config:  environment variables MONGO_URL, DB_NAME, MQTT_PORT, HTTP_PORT, ROOM

const net = require('net');
const crypto = require('crypto');
const express = require('express');
const { MongoClient } = require('mongodb');
const createAedes = require('aedes');
const { setupDatabase } = require('./db');

const CONFIG = {
  mongoUrl: process.env.MONGO_URL || 'mongodb://127.0.0.1:27017',
  dbName: process.env.DB_NAME || 'roomsense',
  mqttPort: Number(process.env.MQTT_PORT || 1883),
  httpPort: Number(process.env.HTTP_PORT || 3000),
  room: process.env.ROOM || 'ME407'
};

// ---------- validation helpers ----------
class BadInput extends Error {}
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
function num(v, min, max, name) {
  if (!isNum(v) || v < min || v > max) throw new BadInput(`${name} must be a number between ${min} and ${max}`);
  return v;
}
function bool(v, name) {
  if (typeof v !== 'boolean') throw new BadInput(`${name} must be true or false`);
  return v;
}
function oneOf(v, options, name) {
  if (!options.includes(v)) throw new BadInput(`${name} must be one of ${options.join(', ')}`);
  return v;
}
// The Pi sends epoch seconds. If its clock is clearly wrong, use the server's time instead.
function toDate(ts) {
  const nowMs = Date.now();
  if (!isNum(ts) || Math.abs(ts * 1000 - nowMs) > 24 * 3600 * 1000) return new Date(nowMs);
  return new Date(ts * 1000);
}
const hashUid = (uid) => crypto.createHash('sha256').update(String(uid).trim().toUpperCase()).digest('hex');

// Commands the dashboard may send to each actuator, checked before they reach the Pi.
const ACTUATORS = {
  status: (b) => ({ state: oneOf(b.state, ['free', 'reserved', 'occupied', 'offline'], 'state') }),
  heating: (b) => ({ on: bool(b.on, 'on') }),
  light: (b) => ({ on: bool(b.on, 'on'), level: b.level === undefined ? 1 : num(b.level, 0, 1, 'level') }),
  fan: (b) => ({ on: bool(b.on, 'on'), speed: b.speed === undefined ? 0.9 : num(b.speed, 0, 1, 'speed') })
};

// Sensor payloads from the Pi -> rows for the time-series collection.
const SENSORS = {
  presence: (d) => [['presence', bool(d.presence, 'presence') ? 1 : 0]],
  climate: (d) => {
    const rows = [
      ['temperature', num(d.celsius, -40, 85, 'celsius')],
      ['humidity', num(d.humidity, 0, 100, 'humidity')],
      ['pressure', num(d.hPa, 300, 1100, 'hPa')]
    ];
    if (d.gasOhms !== null && d.gasOhms !== undefined) rows.push(['gas', num(d.gasOhms, 0, 1e9, 'gasOhms')]);
    return rows;
  },
  light: (d) => [['light', num(d.lux, 0, 200000, 'lux')]]
};

const TOPIC = /^campus\/([A-Za-z0-9_-]+)\/(.+)$/;
const SERVER_ONLY = /^campus\/[^/]+\/(actuator\/[^/]+\/set|rfid\/result)$/;

function createApp(db, cfg = CONFIG) {
  const aedes = createAedes();
  const readings = db.collection('sensor_readings');
  const events = db.collection('events');
  const rooms = db.collection('rooms');
  const users = db.collection('users');
  const sseClients = new Set();
  let lastUnknownUid = null;   // kept in memory only, to help register a new badge

  const broadcast = (type, data) => {
    const line = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const res of sseClients) res.write(line);
  };
  const logEvent = (roomId, type, source, details = {}, userId = null) =>
    events.insertOne({ ts: new Date(), roomId, type, source, userId, details });

  const publish = (topic, payload, { qos = 1, retain = false } = {}) =>
    new Promise((resolve, reject) =>
      aedes.publish({ cmd: 'publish', topic, payload: Buffer.from(JSON.stringify(payload)), qos, retain, dup: false },
        (err) => (err ? reject(err) : resolve())));

  // Only the server may send commands; a client trying to publish one is refused.
  aedes.authorizePublish = (client, packet, callback) => {
    if (client && SERVER_ONLY.test(packet.topic)) return callback(new Error(`clients may not publish to ${packet.topic}`));
    callback(null);
  };

  async function handleRfid(roomId, data) {
    if (typeof data.uid !== 'string' || !/^[0-9A-Fa-f]{10}$/.test(data.uid)) throw new BadInput('uid must be 10 hex characters');
    const user = await users.findOne({ rfidUidHash: hashUid(data.uid) });
    // v1 rule: any registered badge is granted. Booking checks come with the room logic (v2).
    const granted = Boolean(user);
    const reason = granted ? `welcome ${user.name}` : 'unknown badge';
    if (!granted) lastUnknownUid = { uid: data.uid.toUpperCase(), roomId, at: new Date() };
    await publish(`campus/${roomId}/rfid/result`, { granted, reason });
    await logEvent(roomId, granted ? 'access_granted' : 'access_denied', 'node', {}, user ? user._id : null);
    broadcast('access', { roomId, granted, user: user ? user.name : null, ts: new Date() });
  }

  async function handleMessage(topic, raw) {
    const m = TOPIC.exec(topic);
    if (!m) return;
    const [, roomId, sub] = m;
    const text = raw.toString();

    if (sub === 'node/status') {
      const status = oneOf(text, ['online', 'offline'], 'node status');
      await rooms.updateOne({ _id: roomId }, { $set: { nodeStatus: status, lastSeen: new Date() } });
      await logEvent(roomId, status === 'online' ? 'node_online' : 'node_offline', 'node');
      broadcast('node', { roomId, status, ts: new Date() });
      return;
    }

    const data = JSON.parse(text);
    if (typeof data !== 'object' || data === null) throw new BadInput('payload must be a JSON object');

    if (sub.startsWith('sensor/')) {
      const kind = sub.slice('sensor/'.length);
      await rooms.updateOne({ _id: roomId }, { $set: { lastSeen: new Date() } });
      if (kind === 'rfid') return handleRfid(roomId, data);
      const toRows = SENSORS[kind];
      if (!toRows) throw new BadInput(`unknown sensor ${kind}`);
      const ts = toDate(data.ts);
      const rows = toRows(data).map(([type, value]) => ({ ts, meta: { roomId, type }, value }));
      await readings.insertMany(rows);
      broadcast('reading', { roomId, ts, values: Object.fromEntries(rows.map((r) => [r.meta.type, r.value])) });
      return;
    }

    const state = /^actuator\/([a-z]+)\/state$/.exec(sub);
    if (state) {
      await rooms.updateOne({ _id: roomId }, { $set: { [`actuators.${state[1]}`]: { ...data, ts: new Date() } } });
      broadcast('actuator', { roomId, actuator: state[1], ...data });
    }
  }

  aedes.on('publish', (packet, client) => {
    if (!client) return; // our own publishes
    handleMessage(packet.topic, packet.payload).catch(async (err) => {
      console.warn(`rejected ${packet.topic}: ${err.message}`);
      const m = TOPIC.exec(packet.topic);
      if (m) await logEvent(m[1], 'bad_message', 'node', { topic: packet.topic, error: err.message }).catch(() => {});
    });
  });
  aedes.on('client', (c) => console.log(`MQTT connected:    ${c.id}`));
  aedes.on('clientDisconnect', (c) => console.log(`MQTT disconnected: ${c.id}`));

  // ---------- REST API ----------
  const app = express();
  app.use(express.json());
  app.use((req, res, next) => {          // allow the Angular dev server (ng serve) to call the API
    res.set('Access-Control-Allow-Origin', 'http://localhost:4200');
    res.set('Access-Control-Allow-Headers', 'Content-Type');
    res.set('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE');
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });
  const wrap = (fn) => (req, res, next) => fn(req, res).catch(next);
  const findRoom = async (id, res) => {
    const room = await rooms.findOne({ _id: id });
    if (!room) res.status(404).json({ error: `room ${id} not found` });
    return room;
  };

  app.get('/api/health', (req, res) => res.json({ ok: true, mqttClients: aedes.connectedClients }));

  app.get('/api/rooms', wrap(async (req, res) => res.json(await rooms.find({}).toArray())));

  app.get('/api/rooms/:id', wrap(async (req, res) => {
    const room = await findRoom(req.params.id, res);
    if (!room) return;
    const types = ['presence', 'temperature', 'humidity', 'pressure', 'gas', 'light'];
    const latest = {};
    await Promise.all(types.map(async (type) => {
      const doc = await readings.find({ 'meta.roomId': room._id, 'meta.type': type }).sort({ ts: -1 }).limit(1).toArray();
      if (doc.length) latest[type] = { value: doc[0].value, ts: doc[0].ts };
    }));
    res.json({ ...room, latest });
  }));

  app.get('/api/rooms/:id/readings', wrap(async (req, res) => {
    const type = String(req.query.type || 'temperature');
    const hours = Math.min(Math.max(Number(req.query.hours) || 24, 1), 24 * 30);
    const since = new Date(Date.now() - hours * 3600 * 1000);
    const rows = await readings
      .find({ 'meta.roomId': req.params.id, 'meta.type': type, ts: { $gte: since } }, { projection: { _id: 0, ts: 1, value: 1 } })
      .sort({ ts: 1 }).limit(5000).toArray();
    res.json(rows);
  }));

  // The web-triggered actuators: dashboard -> this API -> broker -> Pi.
  app.post('/api/rooms/:id/actuators/:name', wrap(async (req, res) => {
    const build = ACTUATORS[req.params.name];
    if (!build) return res.status(404).json({ error: `unknown actuator ${req.params.name}` });
    const room = await findRoom(req.params.id, res);
    if (!room) return;
    const command = build(req.body || {});
    await publish(`campus/${room._id}/actuator/${req.params.name}/set`, command, { qos: 1, retain: true });
    await logEvent(room._id, 'override', 'web', { actuator: req.params.name, command });
    res.status(202).json({ sent: command, nodeStatus: room.nodeStatus });
  }));

  app.get('/api/events', wrap(async (req, res) => {
    const filter = req.query.roomId ? { roomId: String(req.query.roomId) } : {};
    const limit = Math.min(Number(req.query.limit) || 50, 200);
    res.json(await events.find(filter).sort({ ts: -1 }).limit(limit).toArray());
  }));

  app.get('/api/users', wrap(async (req, res) =>
    res.json(await users.find({}, { projection: { rfidUidHash: 0 } }).toArray())));

  app.post('/api/users', wrap(async (req, res) => {
    const { name, email, role = 'student', rfidUid } = req.body || {};
    if (typeof name !== 'string' || !name.trim()) throw new BadInput('name is required');
    if (typeof rfidUid !== 'string' || !/^[0-9A-Fa-f]{10}$/.test(rfidUid)) throw new BadInput('rfidUid must be 10 hex characters');
    oneOf(role, ['student', 'admin'], 'role');
    const doc = { name: name.trim(), role, rfidUidHash: hashUid(rfidUid), createdAt: new Date() };
    if (email) doc.email = String(email).trim().toLowerCase();
    try {
      const { insertedId } = await users.insertOne(doc);
      res.status(201).json({ _id: insertedId, name: doc.name, role, email: doc.email });
    } catch (err) {
      if (err.code === 11000) return res.status(409).json({ error: 'this badge or email is already registered' });
      throw err;
    }
  }));

  // The last badge that was refused, so it can be registered from the dashboard without retyping it.
  app.get('/api/rfid/last-unknown', (req, res) => res.json(lastUnknownUid));

  // Live updates for the dashboard (server-sent events: no extra library on either side).
  app.get('/api/stream', (req, res) => {
    res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    res.flushHeaders();
    res.write('event: hello\ndata: {}\n\n');
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
  });

  app.use((err, req, res, next) => {
    if (err instanceof BadInput || err.type === 'entity.parse.failed') return res.status(400).json({ error: err.message });
    console.error(err);
    res.status(500).json({ error: 'internal error' });
  });

  const mqttServer = net.createServer(aedes.handle);
  return { aedes, app, mqttServer, handleMessage, close: () => new Promise((r) => { mqttServer.close(); aedes.close(r); }) };
}

async function main() {
  const client = new MongoClient(CONFIG.mongoUrl, { serverSelectionTimeoutMS: 5000 });
  try {
    await client.connect();
  } catch (err) {
    console.error(`Cannot reach MongoDB at ${CONFIG.mongoUrl}. Is the MongoDB service running?\n${err.message}`);
    process.exit(1);
  }
  const db = client.db(CONFIG.dbName);
  await setupDatabase(db, CONFIG.room);
  const { app, mqttServer } = createApp(db, CONFIG);
  mqttServer.listen(CONFIG.mqttPort, '0.0.0.0', () => console.log(`MQTT broker on port ${CONFIG.mqttPort}`));
  app.listen(CONFIG.httpPort, () => console.log(`API on http://localhost:${CONFIG.httpPort}/api/health`));
}

if (require.main === module) main();

module.exports = { createApp, hashUid, ACTUATORS, SENSORS };
