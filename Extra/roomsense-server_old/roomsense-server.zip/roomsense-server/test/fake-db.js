// Minimal in-memory stand-in for the MongoDB driver, covering only what server.js uses.
// For automated tests without a MongoDB server; the real server uses MongoDB.
const { ObjectId } = require('mongodb');

const get = (doc, path) => path.split('.').reduce((v, k) => (v == null ? undefined : v[k]), doc);
const set = (doc, path, value) => {
  const keys = path.split('.');
  let cur = doc;
  keys.slice(0, -1).forEach((k) => { cur[k] = cur[k] && typeof cur[k] === 'object' ? cur[k] : {}; cur = cur[k]; });
  cur[keys[keys.length - 1]] = value;
};
const cmp = (a, b) => (a instanceof Date ? a.getTime() : a) - (b instanceof Date ? b.getTime() : b);
const matches = (doc, filter) => Object.entries(filter).every(([path, cond]) => {
  const v = get(doc, path);
  if (cond && typeof cond === 'object' && !(cond instanceof Date) && !(cond instanceof ObjectId)) {
    if ('$gte' in cond) return v !== undefined && cmp(v, cond.$gte) >= 0;
  }
  if (cond instanceof ObjectId) return v instanceof ObjectId && v.equals(cond);
  return v === cond || (v instanceof Date && cond instanceof Date && v.getTime() === cond.getTime());
});

class Cursor {
  constructor(docs, projection) { this.docs = docs; this.projection = projection; }
  sort(spec) {
    const [[key, dir]] = Object.entries(spec);
    this.docs.sort((a, b) => dir * cmp(get(a, key), get(b, key)));
    return this;
  }
  limit(n) { this.docs = this.docs.slice(0, n); return this; }
  async toArray() {
    if (!this.projection) return this.docs.map((d) => ({ ...d }));
    const include = Object.entries(this.projection).filter(([, v]) => v === 1).map(([k]) => k);
    const exclude = Object.entries(this.projection).filter(([, v]) => v === 0).map(([k]) => k);
    return this.docs.map((d) => {
      if (include.length) return Object.fromEntries(include.filter((k) => k in d).map((k) => [k, d[k]]));
      const copy = { ...d }; exclude.forEach((k) => delete copy[k]); return copy;
    });
  }
}

class Collection {
  constructor() { this.docs = []; this.unique = []; }
  checkUnique(doc) {
    for (const key of this.unique) {
      const v = get(doc, key);
      if (v !== undefined && this.docs.some((d) => d !== doc && get(d, key) === v)) {
        const err = new Error('duplicate key'); err.code = 11000; throw err;
      }
    }
  }
  async insertOne(doc) {
    const d = { _id: new ObjectId(), ...doc };
    this.checkUnique(d); this.docs.push(d);
    return { insertedId: d._id };
  }
  async insertMany(docs) { for (const d of docs) await this.insertOne(d); return { insertedCount: docs.length }; }
  async findOne(filter) { return this.docs.find((d) => matches(d, filter)) || null; }
  find(filter = {}, options = {}) { return new Cursor(this.docs.filter((d) => matches(d, filter)), options.projection); }
  async updateOne(filter, update, options = {}) {
    let doc = this.docs.find((d) => matches(d, filter));
    if (!doc && options.upsert) {
      doc = { ...filter };
      Object.entries(update.$setOnInsert || {}).forEach(([k, v]) => set(doc, k, v));
      this.docs.push(doc);
    }
    if (doc) Object.entries(update.$set || {}).forEach(([k, v]) => set(doc, k, v));
    return { matchedCount: doc ? 1 : 0 };
  }
  async createIndex(spec, opts = {}) { if (opts.unique) this.unique.push(...Object.keys(spec)); }
}

class FakeDb {
  constructor() { this.cols = {}; }
  collection(name) { return (this.cols[name] = this.cols[name] || new Collection()); }
}

module.exports = { FakeDb };
